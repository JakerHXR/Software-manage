package com.example.myapplication.util;

public class food_Content {

}
