package com.example.myapplication.model;

import java.util.ArrayList;

public class food {
    public String food_name;
    public ArrayList<String> tag=new ArrayList<>();
    public String food_no;
}
