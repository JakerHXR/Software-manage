package com.example.myapplication.model;

public class admin {
    public  String admin_id;
    public  String admin_pass;
}
